import React from 'react';
import ReactDom from 'react-dom';

ReactDom.render(
    <h1>Hola React con webpack</h1>,
    document.getElementById('root')
)