const path = require('path');
const yaml = require('yamljs');
const json5 = require('json5');

module.exports = {
    entry: './src/index.ts',
    devtool: 'inline-source-map',
    output:{
        filename: 'bundle.js',
        path: path.resolve(__dirname,'dist') //Lugar donde va el código optimizado (carpeta estándar)
    },
    //Integrar modulo para paquetes adicionales o cargadores
    module:{
        rules:[
            {
                test: /\.css$/i, //Tipo de archivo que se utilizará
                use: ['style-loader', 'css-loader'], //llamada del cargador instalado mediante npm
            },
            //Para trabajar con imágenes
            {
                test: /\.(png|jpg)$/i, //Tipo de archivo que se utilizará
                type: 'asset/resource', //Especificar que se trata de un activo o recurso
            },
            //Para trabajar con archivos csv
            {
                test: /\.csv$/i,
                use: ['csv-loader'],
            },
            //Yaml
            {
                test: /\.yaml$/i, //Tipo de archivo que se utilizará
                type: 'json', //Especificar que se trate como archivo de tipo JSON
                parser:{
                    parse: yaml.parse
                }
            },
            //Json5
            {
                test: /\.json5$/i, //Tipo de archivo que se utilizará
                type: 'json', //Especificar que se trate como archivo de tipo JSON
                parser:{
                    parse: json5.parse
                }
            },
            //SCSS
            {
                test: /\.s[ac]ss$/i, //Tipo de archivo que se utilizará
                use: ['style-loader', 'css-loader', 'sass-loader'], //llamada del cargador instalado mediante npm
            },
            //Typescript
            {
                test: /\.tsx?$/, //Tipo de archivo que se utilizará
                use: 'ts-loader',
                exclude: /node_modules/
            }
        ],
    },
    resolve:{
        extensions: ['.tsx', '.ts', '.js'],
    }
}