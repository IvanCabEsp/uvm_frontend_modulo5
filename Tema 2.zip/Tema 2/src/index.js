import _ from 'lodash';

function componente (){
    //Mostrar leyenda de saludo (customelement en DOM)
    const elemento = document.createElement('div');
    //Modificar la etiqueta div e insertarle contenido con la función "join"
    elemento.innerHTML = _.join(['Hola', 'Webpack'],' '); //Función que contiene un arreglo de objetos
    return elemento; //Regresar elemento para que pueda ser visualizado
}

document.body.appendChild(componente()); //Agregar todo el contenido de la función "componente" al DOM