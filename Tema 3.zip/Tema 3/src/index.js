import _ from 'lodash';
import './estilo.css';
import Imagen from './BMW Serie 2.jpg';
import Datos from './datos.csv';
import yaml from './datos.yaml';
import json5 from './datos.json5';

function componente (){
    //Mostrar leyenda de saludo (customelement en DOM)
    const elemento = document.createElement('div');
    //Modificar la etiqueta div e insertarle contenido con la función "join"
    elemento.innerHTML = _.join(['Hola', 'Webpack'],' '); //Función que contiene un arreglo de objetos
    elemento.classList.add('hola'); //Agregar al DOM clase con el nombre de "hola"
    const miImagen = new Image();
    miImagen.src = Imagen;
    elemento.appendChild(miImagen); //Agregar el contenido de la variable miImagen al DOM

    console.log(Datos);
    return elemento; //Regresar elemento para que pueda ser visualizado
}

console.log(yaml.title);
console.log(json5.owner.name);
document.body.appendChild(componente()); //Agregar todo el contenido de la función "componente" al DOM